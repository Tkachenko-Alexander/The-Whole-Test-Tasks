select *
  from fw_contracts f
 where f.dt_start <= current_timestamp
   and f.dt_stop > current_timestamp
   and f.v_ext_ident = '0133000000049669_MOB';

select *
  from fw_contracts f
  join TRANS_EXTERNAL t
    on t.id_contract = f.id_contract_inst
 where f.dt_start <= current_timestamp
   and f.dt_stop > current_timestamp
   and f.v_ext_ident = '0133000000049669_MOB';

select *
  from fw_contracts f
  join TRANS_EXTERNAL t
    on t.id_contract = f.id_contract_inst
   and t.dt_event >= trunc(current_timestamp, 'year')
 where f.dt_start <= current_timestamp
   and f.dt_stop > current_timestamp
   and f.v_ext_ident = '0133000000049669_MOB';
   
   
select f.v_ext_ident, t.f_sum, t.dt_event, t.v_status, d.id_department
  from fw_contracts f
  join TRANS_EXTERNAL t
    on t.id_contract = f.id_contract_inst
   and t.dt_event >= trunc(current_timestamp, 'year')
  left join fw_departments d
    on d.id_department = f.id_department
   and d.b_deleted = 0
 where f.dt_start <= current_timestamp
   and f.dt_stop > current_timestamp
   and f.v_ext_ident = '0133000000049669_MOB';
