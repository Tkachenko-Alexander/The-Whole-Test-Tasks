select f.v_ext_ident, dt_cont.min_dt_start, d.v_name
  from fw_contracts f
  left join fw_departments d
  on d.id_department = f.id_department
  and d.b_deleted = 0
  join (select min(fc.dt_start) as min_dt_start, fc.id_contract_inst
          from fw_contracts fc
         group by fc.id_contract_inst) dt_cont
    on dt_cont.id_contract_inst = f.id_contract_inst
   and dt_cont.min_dt_start >= to_date('2017-01-01', 'yyyy-mm-dd')
   and dt_cont.min_dt_start < to_date('2018-01-01', 'yyyy-mm-dd') -- ����� ����� dt_reg. ����� ������ ���� �������
 where f.dt_start <= current_timestamp
   and f.dt_stop > current_timestamp
   and 2 < (select count(1)
              from TRANS_EXTERNAL t
             where t.id_contract = f.id_contract_inst)
   and exists (select 1
          from TRANS_EXTERNAL te
          join fw_contracts ff
            on ff.dt_start <= current_timestamp
           and ff.dt_stop > current_timestamp
           and ff.id_contract_inst = te.id_contract
          join (select avg(tet.f_sum) as avg_sum, fct.id_department
                 from TRANS_EXTERNAL tet
                 join fw_contracts fct
                   on fct.dt_start <= current_timestamp
                  and fct.dt_stop > current_timestamp
				  and fct.id_contract_inst = tet.id_contract
				where tet.v_status = 'A'
                group by fct.id_department) avg_dep
            on avg_dep.avg_sum > te.f_sum
           and avg_dep.id_department = ff.id_department
         where te.id_contract = f.id_contract_inst
		 and te.v_status = 'A');
