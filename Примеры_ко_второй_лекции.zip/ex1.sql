
select * from example1;
select * from example2;
select * from example1 e1 join example2 e2 on e1.id = e2.id order by e1.id;
select * from example1 e1 left join example2 e2 on e1.id = e2.id order by e1.id;
select * from example1 e1, example2 e2 where e1.id = e2.id 
select * from example1 e1 right join example2 e2 on e1.id = e2.id order by e2.id;
select * from example1 e1 full outer join example2 e2 on e1.id = e2.id order by e1.id;
/*
1 1           null 1
2 2           null 11
2 2           2    2
3 3           3    3
null 4        3    3
5 5*/
